import { useEffect, useState, type ComponentType } from "react";
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  const [View, setView] = useState<ComponentType | null>(null);

  useEffect(() => {
    void import("@/game/GameView.tsx").then((m) => setView(() => m.GameView));
  }, []);

  if (!View) {
    return (
      <div className="grid min-h-dvh place-items-center bg-bg px-6 text-fg">
        <div className="text-center">
          <p className="font-display text-[11px] uppercase tracking-[0.28em] text-accent">Naiwan. Hanapin.</p>
          <h1 className="mt-2 font-display text-4xl tracking-tight">Bakuran</h1>
          <p className="mt-3 text-sm text-muted">Preparing the grounds…</p>
        </div>
      </div>
    );
  }

  return <View />;
}
