import { useMemo, useState, type ReactNode } from "react";
import { Check, ChevronRight, Star, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getSharedAudio } from "@/game/audio.ts";
import { LEVELS, isUnlocked } from "@/game/levels.ts";
import { TIME_PRESETS, TOTAL_LEVELS } from "@/game/catalog.ts";
import { useGameUi } from "@/game/store.ts";
import { cn, formatClock, sanitizeUsername } from "@/lib/utils";
import type { Quality } from "@/game/types.ts";

export function FlowScreens() {
  const flow = useGameUi((s) => s.flow);
  if (flow === "game") return null;
  return (
    <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-bg/50 p-4">
      {flow === "title" && <TitleScreen />}
      {flow === "login" && <LoginScreen />}
      {flow === "menu" && <MenuScreen />}
      {flow === "profile" && <ProfileScreen />}
      {flow === "levels" && <LevelScreen />}
      {flow === "settings" && <SettingsScreen onBack={() => useGameUi.getState().setFlow("menu")} />}
    </div>
  );
}

function Shell({
  kicker,
  title,
  children,
  wide,
}: {
  kicker: string;
  title: string;
  children: ReactNode;
  wide?: boolean;
}) {
  return (
    <div
      className={cn(
        "panel-in w-full rounded-[28px] border border-border bg-surface p-6 shadow-[var(--shadow-panel)] sm:p-8",
        wide ? "max-w-2xl" : "max-w-lg",
      )}
    >
      <p className="font-display text-[11px] uppercase tracking-[0.28em] text-accent">{kicker}</p>
      <h1 className="mt-2 font-display text-4xl tracking-tight">{title}</h1>
      {children}
    </div>
  );
}

function TitleScreen() {
  const setFlow = useGameUi((s) => s.setFlow);
  const username = useGameUi((s) => s.save.username);
  return (
    <Shell kicker="Naiwan. Hanapin." title="Bakuran">
      <p className="mt-3 text-sm text-muted">
        A quiet walk through ancestral grounds. Find what was left behind before the light goes.
      </p>
      <Button
        className="mt-6 w-full"
        size="lg"
        onClick={() => {
          getSharedAudio().unlock();
          setFlow(username ? "menu" : "login");
        }}
      >
        Enter the grounds
      </Button>
    </Shell>
  );
}

function LoginScreen() {
  const login = useGameUi((s) => s.login);
  const existing = useGameUi((s) => s.save.username);
  const [name, setName] = useState(existing);
  const preview = sanitizeUsername(name);
  return (
    <Shell kicker="Sino ka?" title="Your name">
      <p className="mt-3 text-sm text-muted">This is how the grounds will call you. Saved on this device.</p>
      <label className="mt-5 block text-[11px] uppercase tracking-[0.16em] text-subtle" htmlFor="player-name">
        Enter your name
      </label>
      <input
        id="player-name"
        autoFocus
        maxLength={16}
        value={name}
        onChange={(e) => setName(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && preview) login(name);
        }}
        placeholder="Juan"
        className="mt-2 h-12 w-full rounded-[16px] border border-border bg-elevated px-4 text-base text-fg outline-none ring-accent/60 focus:ring-2"
      />
      <p className="mt-2 text-xs text-subtle">Shown as {preview}</p>
      <Button className="mt-6 w-full" size="lg" disabled={!name.trim()} onClick={() => login(name)}>
        Continue
      </Button>
    </Shell>
  );
}

function MenuScreen() {
  const save = useGameUi((s) => s.save);
  const setFlow = useGameUi((s) => s.setFlow);
  const setLevel = useGameUi((s) => s.setLevel);
  const next = Math.min(TOTAL_LEVELS, (Math.max(0, ...save.completed) || 0) + 1);
  const continueId = isUnlocked(save.lastLevel, save.completed) ? save.lastLevel : next;
  return (
    <Shell kicker={`Kumusta, ${save.username}`} title="Bakuran">
      <p className="mt-3 text-sm text-muted">Walk the grounds. Ten searches. One ancestral yard.</p>
      <div className="mt-6 space-y-2">
        <Button className="w-full" size="lg" onClick={() => setLevel(continueId)}>
          {save.completed.length ? "Continue walk" : "Begin walk"}
        </Button>
        <Button className="w-full" variant="secondary" onClick={() => setFlow("levels")}>
          Level select
        </Button>
        <Button className="w-full" variant="secondary" onClick={() => setFlow("profile")}>
          Player profile
        </Button>
        <Button className="w-full" variant="ghost" onClick={() => setFlow("settings")}>
          Settings
        </Button>
      </div>
      <p className="mt-4 text-center text-[11px] text-subtle">
        {save.completed.length} / {TOTAL_LEVELS} complete
      </p>
    </Shell>
  );
}

function ProfileScreen() {
  const save = useGameUi((s) => s.save);
  const setFlow = useGameUi((s) => s.setFlow);
  const progress = Math.round((save.completed.length / TOTAL_LEVELS) * 100);
  const best = Object.values(save.bestTime);
  const bestOverall = best.length ? Math.min(...best) : null;
  return (
    <Shell kicker="Player profile" title={save.username || "Kaibigan"}>
      <div className="mt-5 grid grid-cols-2 gap-2">
        <Stat label="Level" value={`${Math.min(TOTAL_LEVELS, save.completed.length + 1)} / ${TOTAL_LEVELS}`} />
        <Stat label="Items found" value={String(save.itemsFound)} />
        <Stat label="Best time" value={bestOverall ? formatClock(bestOverall) : "—"} />
        <Stat label="Walks done" value={String(save.completed.length)} />
      </div>
      <p className="mt-5 text-[11px] uppercase tracking-[0.16em] text-subtle">Progress</p>
      <div className="mt-2 h-2 overflow-hidden rounded-full bg-elevated">
        <div className="h-full bg-accent" style={{ width: `${progress}%` }} />
      </div>
      <p className="mt-1 text-xs text-muted">{progress}%</p>
      <Button className="mt-6 w-full" variant="secondary" onClick={() => setFlow("menu")}>
        Back
      </Button>
    </Shell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-[12px] border border-border bg-elevated px-3 py-2">
      <p className="text-[10px] uppercase tracking-wider text-subtle">{label}</p>
      <p className="font-display text-lg tabular">{value}</p>
    </div>
  );
}

function LevelScreen() {
  const save = useGameUi((s) => s.save);
  const setFlow = useGameUi((s) => s.setFlow);
  const setLevel = useGameUi((s) => s.setLevel);
  return (
    <Shell kicker="Hanapin" title="Level select" wide>
      <ul className="mt-5 max-h-[50dvh] space-y-2 overflow-auto pr-1">
        {LEVELS.map((lv) => {
          const open = isUnlocked(lv.id, save.completed);
          const done = save.completed.includes(lv.id);
          const stars = save.stars[String(lv.id)] ?? 0;
          return (
            <li key={lv.id}>
              <button
                type="button"
                disabled={!open}
                onClick={() => open && setLevel(lv.id)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-[16px] border px-3 py-3 text-left transition-opacity",
                  open ? "border-border bg-elevated hover:border-accent" : "border-border/60 bg-bg opacity-50",
                )}
              >
                <span className="grid size-10 shrink-0 place-items-center rounded-[12px] bg-surface font-display text-sm">
                  {lv.id}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-medium">{lv.tagalog}</span>
                  <span className="block truncate text-xs text-muted">
                    {lv.title} · {TIME_PRESETS[lv.timeOfDay].label}
                  </span>
                </span>
                <span className="flex items-center gap-1 text-warn">
                  {done
                    ? Array.from({ length: 5 }, (_, i) => (
                        <Star key={i} className={cn("size-3", i < stars ? "fill-warn" : "text-subtle")} />
                      ))
                    : open
                      ? <ChevronRight className="size-4 text-muted" />
                      : null}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
      <Button className="mt-5 w-full" variant="ghost" onClick={() => setFlow("menu")}>
        Back
      </Button>
    </Shell>
  );
}

export function SettingsScreen({ onBack }: { onBack: () => void }) {
  const settings = useGameUi((s) => s.save.settings);
  const update = useGameUi((s) => s.updateSettings);
  return (
    <div className="panel-in w-full max-w-md rounded-[28px] border border-border bg-surface p-6 shadow-[var(--shadow-panel)]">
      <p className="font-display text-[11px] uppercase tracking-[0.28em] text-accent">Settings</p>
      <h2 className="mt-2 font-display text-3xl">Tune the walk</h2>
      <div className="mt-5 space-y-5">
        <Slider label="Music" value={settings.music} onChange={(v) => update({ music: v })} />
        <Slider label="Sound" value={settings.sfx} onChange={(v) => update({ sfx: v })} />
        <div>
          <p className="text-[11px] uppercase tracking-[0.16em] text-subtle">Quality</p>
          <div className="mt-2 grid grid-cols-3 gap-2">
            {(["low", "medium", "high"] as Quality[]).map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => update({ quality: q })}
                className={cn(
                  "rounded-[12px] border px-3 py-2 text-sm capitalize",
                  settings.quality === q ? "border-accent bg-elevated text-fg" : "border-border text-muted",
                )}
              >
                {q}
              </button>
            ))}
          </div>
        </div>
        <Toggle
          label="Minimap"
          on={settings.minimap}
          onChange={(v) => update({ minimap: v })}
        />
        <Toggle
          label="Dialogue"
          on={settings.dialogue}
          onChange={(v) => update({ dialogue: v })}
        />
        <Slider
          label="Text size"
          value={(settings.textScale - 0.85) / 0.4}
          onChange={(v) => update({ textScale: 0.85 + v * 0.4 })}
        />
      </div>
      <Button className="mt-6 w-full" variant="secondary" onClick={onBack}>
        Back
      </Button>
    </div>
  );
}

function Slider({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <label className="block">
      <span className="text-[11px] uppercase tracking-[0.16em] text-subtle">{label}</span>
      <input
        type="range"
        min={0}
        max={1}
        step={0.01}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-2 w-full accent-[var(--color-accent)]"
      />
    </label>
  );
}

function Toggle({ label, on, onChange }: { label: string; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button type="button" onClick={() => onChange(!on)} className="flex w-full items-center justify-between">
      <span className="text-sm">{label}</span>
      <span
        className={cn(
          "grid size-8 place-items-center rounded-[8px] border",
          on ? "border-ok bg-ok/20 text-ok" : "border-border text-subtle",
        )}
      >
        {on ? <Check className="size-4" /> : null}
      </span>
    </button>
  );
}

export function ResultPanel({
  win,
  onNext,
  onRetry,
  onMenu,
}: {
  win: boolean;
  onNext: () => void;
  onRetry: () => void;
  onMenu: () => void;
}) {
  const hud = useGameUi((s) => s.hud);
  const save = useGameUi((s) => s.save);
  const levelId = useGameUi((s) => s.levelId);
  const used = hud ? Math.max(0, hud.timeLimit - hud.remaining) : 0;
  const stars = save.stars[String(levelId)] ?? 0;
  const next = levelId < TOTAL_LEVELS ? levelId + 1 : null;
  const name = save.username;

  const copy = useMemo(() => {
    if (!win) return { kicker: "Naubos ang oras", title: "Time's up", body: `${name}, next time. The path is still there.` };
    if (next) return { kicker: "Nakuha lahat", title: "Level complete", body: `Great job, ${name}.` };
    return { kicker: "Huling hanap", title: "The grounds are quiet", body: `${name}, you found everything that was left.` };
  }, [win, next, name]);

  return (
    <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-bg/70 p-4">
      <div className="panel-in w-full max-w-md rounded-[28px] border border-border bg-surface p-8 text-center">
        <p className={cn("font-display text-[11px] uppercase tracking-[0.28em]", win ? "text-ok" : "text-danger")}>
          {copy.kicker}
        </p>
        <h2 className="mt-2 font-display text-3xl tracking-tight">{copy.title}</h2>
        <p className="mt-3 text-sm text-muted">{copy.body}</p>
        {hud && (
          <div className="mt-5 grid grid-cols-3 gap-2 text-center">
            <Stat label="Time" value={formatClock(used)} />
            <Stat label="Items" value={`${hud.found.length}/${hud.total}`} />
            <Stat label="Left" value={formatClock(hud.remaining)} />
          </div>
        )}
        {win && (
          <div className="mt-4 flex justify-center gap-1 text-warn">
            {Array.from({ length: 5 }, (_, i) => (
              <Star key={i} className={cn("size-5", i < stars ? "fill-warn" : "text-subtle")} />
            ))}
          </div>
        )}
        {win && next && <p className="mt-3 text-xs text-accent">Level {next} unlocked</p>}
        <div className="mt-6 space-y-2">
          {win && next ? (
            <Button className="w-full" size="lg" onClick={onNext}>
              Next level
            </Button>
          ) : null}
          <Button className="w-full" size="lg" variant={win && next ? "secondary" : "primary"} onClick={onRetry}>
            {win ? "Play again" : "Try again"}
          </Button>
          <Button className="w-full" variant="ghost" onClick={onMenu}>
            Exit to menu
          </Button>
        </div>
      </div>
    </div>
  );
}

export function BriefingPanel({ onEnter }: { onEnter: () => void }) {
  const levelId = useGameUi((s) => s.levelId);
  const name = useGameUi((s) => s.save.username);
  const level = LEVELS[levelId - 1] ?? LEVELS[0];
  return (
    <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-bg/55 p-4">
      <div className="panel-in w-full max-w-lg rounded-[28px] border border-border bg-surface p-6 shadow-[var(--shadow-panel)] sm:p-8">
        <p className="font-display text-[11px] uppercase tracking-[0.28em] text-accent">
          Level {level.id} · {TIME_PRESETS[level.timeOfDay].label}
        </p>
        <h1 className="mt-2 font-display text-4xl tracking-tight">{level.tagalog}</h1>
        <p className="mt-1 text-sm text-muted">{level.title}</p>
        <p className="mt-3 text-sm text-muted">
          {name ? `${name}, ` : ""}
          {level.blurb}
        </p>
        <ul className="mt-4 grid grid-cols-2 gap-1 text-xs text-muted sm:grid-cols-3">
          {level.items.map((it) => (
            <li key={it.id} className="rounded-[8px] border border-border bg-elevated px-2 py-1.5">
              {it.name}
            </li>
          ))}
        </ul>
        <p className="mt-3 text-xs text-subtle">{formatClock(level.timeLimit)} on the clock · {level.items.length} items</p>
        <Button className="mt-6 w-full" size="lg" onClick={onEnter}>
          Begin walk
        </Button>
      </div>
    </div>
  );
}

export function IdentityChip() {
  const name = useGameUi((s) => s.save.username);
  if (!name) return null;
  return (
    <span className="inline-flex items-center gap-1.5 text-[11px] text-subtle">
      <User className="size-3" />
      {name}
    </span>
  );
}
