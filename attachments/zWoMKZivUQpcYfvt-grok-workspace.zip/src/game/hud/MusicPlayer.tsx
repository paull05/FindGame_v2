import { Pause, Play, Volume2 } from "lucide-react";
import { useEffect, useState } from "react";
import { getSharedAudio, SONG, type MusicSnap } from "@/game/audio.ts";
import { useGameUi } from "@/game/store.ts";
import { cn } from "@/lib/utils";

export function MusicPlayer() {
  const flow = useGameUi((s) => s.flow);
  const overlay = useGameUi((s) => s.overlay);
  const musicVol = useGameUi((s) => s.save.settings.music);
  const update = useGameUi((s) => s.updateSettings);
  const [snap, setSnap] = useState<MusicSnap>(() => getSharedAudio().musicSnap());

  useEffect(() => {
    const audio = getSharedAudio();
    setSnap(audio.musicSnap());
    return audio.onChange(() => setSnap(audio.musicSnap()));
  }, []);

  useEffect(() => {
    getSharedAudio().setVolumes({ music: musicVol });
  }, [musicVol]);

  const playing = snap.musicOn;
  const inWalk = flow === "game" && overlay === "none";

  return (
    <div
      className={cn(
        "pointer-events-auto absolute z-30 w-[9.5rem] rounded-[16px] border border-border bg-bg/85 p-2 sm:w-48",
        inWalk ? "right-3 top-[6.75rem] sm:right-4 sm:top-28" : "right-3 bottom-4 sm:right-4",
      )}
    >
      <p className="truncate px-1 text-[10px] uppercase tracking-wider text-subtle">Now playing</p>
      <p className="truncate px-1 font-display text-xs leading-snug">{SONG.name}</p>
      <div className="mt-2 flex items-center gap-2">
        <button
          type="button"
          tabIndex={-1}
          aria-label={playing ? "Pause music" : "Play music"}
          className="grid size-11 shrink-0 place-items-center rounded-[12px] border border-border bg-elevated text-fg hover:border-accent"
          onClick={() => {
            getSharedAudio().toggleMusic();
            setSnap(getSharedAudio().musicSnap());
          }}
        >
          {playing ? <Pause className="size-4" /> : <Play className="size-4 translate-x-px" />}
        </button>
        <label className="flex min-w-0 flex-1 items-center gap-1.5 px-0.5">
          <Volume2 className="size-3.5 shrink-0 text-subtle" />
          <input
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={musicVol}
            onChange={(e) => update({ music: Number(e.target.value) })}
            className="w-full accent-[var(--color-accent)]"
            aria-label="Music volume"
          />
        </label>
      </div>
      <p className="mt-1 truncate px-1 text-[10px] text-subtle">{playing ? "Looping" : "Paused"}</p>
    </div>
  );
}
