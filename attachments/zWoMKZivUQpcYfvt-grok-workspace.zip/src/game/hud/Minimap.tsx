import { ZONES } from "@/game/catalog.ts";
import { cn } from "@/lib/utils";

export function MiniMap({
  simX,
  simZ,
  yaw,
  discovered,
  compact,
}: {
  simX: number;
  simZ: number;
  yaw: number;
  discovered: Set<string>;
  compact?: boolean;
}) {
  const size = compact ? 132 : 280;
  const world = 280;
  const s = size / world;
  const px = (simX + 140) * s;
  const pz = (simZ + 140) * s;
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-[16px] border border-border bg-bg",
        compact ? "size-[132px]" : "mx-auto aspect-square w-full max-w-sm",
      )}
      style={compact ? undefined : { minHeight: size }}
    >
      {ZONES.map((z) => {
        const known = discovered.has(z.id);
        return (
          <div
            key={z.id}
            className="absolute rounded-full border"
            style={{
              left: (z.x + 140) * s,
              top: (z.z + 140) * s,
              width: z.radius * s * 2,
              height: z.radius * s * 2,
              marginLeft: -z.radius * s,
              marginTop: -z.radius * s,
              borderColor: known ? "var(--color-accent)" : "var(--color-border)",
              background: known ? "color-mix(in oklab, var(--color-accent) 18%, transparent)" : "transparent",
            }}
            title={known ? z.tagalog : "Unknown"}
          />
        );
      })}
      <div
        className="absolute size-2.5 rounded-full bg-fg"
        style={{
          left: px,
          top: pz,
          marginLeft: -5,
          marginTop: -5,
          boxShadow: "0 0 0 1px var(--color-bg)",
        }}
      />
      <div
        className="absolute origin-bottom bg-fg"
        style={{
          left: px,
          top: pz,
          width: 2,
          height: 8,
          marginLeft: -1,
          marginTop: -10,
          transform: `rotate(${(-yaw * 180) / Math.PI}deg)`,
        }}
      />
    </div>
  );
}
