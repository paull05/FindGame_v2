import * as THREE from "three";
import { applyWind, getTextures } from "./textures.ts";
import type { Building, TimeOfDay } from "./types.ts";
import { getHeight } from "./world.ts";

const matCache = new Map<string, THREE.MeshStandardMaterial>();

function mat(key: string, params: THREE.MeshStandardMaterialParameters) {
  let m = matCache.get(key);
  if (!m) {
    m = new THREE.MeshStandardMaterial(params);
    matCache.set(key, m);
  }
  return m;
}

function maps() {
  return getTextures();
}

function box(
  g: THREE.Group,
  w: number,
  h: number,
  d: number,
  material: THREE.Material,
  x: number,
  y: number,
  z: number,
  rx = 0,
  ry = 0,
  rz = 0,
  shadow = true,
) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  m.position.set(x, y, z);
  m.rotation.set(rx, ry, rz);
  m.castShadow = shadow;
  m.receiveShadow = true;
  g.add(m);
  return m;
}

export function buildDetailed(b: Building, tod: TimeOfDay): THREE.Group {
  const g = new THREE.Group();
  g.position.set(b.x, 0, b.z);
  const y0 = b.y ?? getHeight(b.x, b.z);
  const night = tod === "night";

  if (b.kind === "house") buildHouse(g, b, y0, night);
  else if (b.kind === "kubo") buildKubo(g, b, y0, night);
  else if (b.kind === "store") buildStore(g, b, y0, night);
  else if (b.kind === "workshop") buildWorkshop(g, b, y0, night);
  else if (b.kind === "greenhouse") buildGreenhouse(g, b, y0, night);
  else if (b.kind === "mill") buildMill(g, b, y0, night);

  g.userData.bid = b.id;
  return g;
}

function buildHouse(g: THREE.Group, b: Building, y0: number, night: boolean) {
  const t = maps();
  const wall = mat(`hw-${b.color}`, { map: t.wood, color: b.color, roughness: 0.86, roughnessMap: t.rough });
  const stone = mat("stone", { map: t.stone, color: 0x5a5e56, roughness: 0.95 });
  const roof = mat(`hr-${b.roof ?? 0x8a4030}`, { map: t.dirt, color: b.roof ?? 0x8a4030, roughness: 0.78 });
  const trim = mat("trim", { color: 0xe8e0d0, roughness: 0.6 });
  const glass = mat(night ? "capiz-n" : "capiz-d", {
    color: 0xe8e4d0,
    emissive: 0xf0d8a8,
    emissiveIntensity: night ? 0.85 : 0.12,
    roughness: 0.35,
  });
  const wood = mat("wood", { map: t.wood, color: 0x5a4634, roughness: 0.9 });

  box(g, b.w, 1.15, b.d, stone, 0, y0 + 0.55, 0);
  box(g, b.w - 0.15, b.h - 1.1, b.d - 0.15, wall, 0, y0 + 1.1 + (b.h - 1.1) / 2, 0);

  const roofH = 1.7;
  const roofW = b.w + 1.1;
  const roofD = b.d / 2 + 0.5;
  box(g, roofW, 0.16, roofD, roof, 0, y0 + b.h + 0.4, -b.d / 4, 0.42, 0, 0);
  box(g, roofW, 0.16, roofD, roof, 0, y0 + b.h + 0.4, b.d / 4, -0.42, 0, 0);
  box(g, 0.2, roofH, b.d + 0.2, wall, -b.w / 2 + 0.1, y0 + b.h + 0.3, 0);
  box(g, 0.2, roofH, b.d + 0.2, wall, b.w / 2 - 0.1, y0 + b.h + 0.3, 0);

  const door = box(g, 1.6, 2.4, 0.12, wood, 0, y0 + 1.35, -b.d / 2 - 0.02);
  door.userData.door = true;
  door.userData.closedYaw = 0;
  box(g, 0.7, 0.9, 0.06, glass, -b.w * 0.28, y0 + 2.5, -b.d / 2 - 0.04);
  box(g, 0.7, 0.9, 0.06, glass, b.w * 0.28, y0 + 2.5, -b.d / 2 - 0.04);
  box(g, 0.7, 0.9, 0.06, glass, -b.w * 0.28, y0 + 2.5, b.d / 2 + 0.04);
  box(g, 0.7, 0.9, 0.06, glass, b.w * 0.28, y0 + 2.5, b.d / 2 + 0.04);

  box(g, b.w * 0.7, 0.12, 2.2, wood, 0, y0 + 0.28, -b.d / 2 - 1.0, 0, 0, 0, false);
  box(g, 0.14, 2.2, 0.14, wood, -b.w * 0.32, y0 + 1.2, -b.d / 2 - 1.9);
  box(g, 0.14, 2.2, 0.14, wood, b.w * 0.32, y0 + 1.2, -b.d / 2 - 1.9);
  box(g, b.w * 0.72, 0.1, 2.4, roof, 0, y0 + 2.35, -b.d / 2 - 1.1, 0.2, 0, 0);

  if (b.enterable) {
    box(g, 1.4, 0.08, 1.1, wood, -2.4, y0 + 0.85, 1.2, 0, 0, 0, false);
    box(g, 0.45, 0.85, 0.45, wood, -2.9, y0 + 0.5, 1.5);
    box(g, 0.45, 0.85, 0.45, wood, -1.9, y0 + 0.5, 1.5);
    box(g, 0.9, 1.6, 0.28, mat("shelf", { map: t.wood, color: 0x4a4030, roughness: 0.9 }), 3.2, y0 + 1.1, 2.6);
  }

  box(g, 0.08, 0.08, 0.08, trim, 0, y0 + b.h + 0.05, -b.d / 2 - 0.1, 0, 0, 0, false);
}

function buildKubo(g: THREE.Group, b: Building, y0: number, night: boolean) {
  const t = maps();
  const wall = mat(`kw-${b.color}`, { map: t.wood, color: b.color, roughness: 0.92 });
  const roof = mat(`kr-${b.roof ?? 0x6a5344}`, { map: t.dirt, color: b.roof ?? 0x6a5344, roughness: 0.88 });
  const post = mat("post", { map: t.wood, color: 0x3a2a1c, roughness: 1 });
  const glass = mat(night ? "kglass-n" : "kglass-d", {
    color: 0xe8e0d0,
    emissive: 0xf0d8a8,
    emissiveIntensity: night ? 0.5 : 0.08,
  });

  const stilts = 0.55;
  box(g, b.w, b.h - stilts, b.d, wall, 0, y0 + stilts + (b.h - stilts) / 2, 0);
  const corners: [number, number][] = [
    [-b.w / 2 + 0.2, -b.d / 2 + 0.2],
    [b.w / 2 - 0.2, -b.d / 2 + 0.2],
    [-b.w / 2 + 0.2, b.d / 2 - 0.2],
    [b.w / 2 - 0.2, b.d / 2 - 0.2],
  ];
  for (const [px, pz] of corners) {
    box(g, 0.16, stilts + 0.2, 0.16, post, px, y0 + stilts / 2, pz);
  }
  box(g, b.w + 1.4, 0.14, b.d / 2 + 0.8, roof, 0, y0 + b.h + 0.55, -b.d / 4, 0.55, 0, 0);
  box(g, b.w + 1.4, 0.14, b.d / 2 + 0.8, roof, 0, y0 + b.h + 0.55, b.d / 4, -0.55, 0, 0);
  box(g, 0.7, 0.7, 0.06, glass, 0, y0 + stilts + 1.3, -b.d / 2 - 0.04);
  box(g, 0.9, 1.6, 0.08, post, 0.6, y0 + stilts + 0.9, -b.d / 2 - 0.02);
}

function buildStore(g: THREE.Group, b: Building, y0: number, night: boolean) {
  const t = maps();
  const wall = mat(`sw-${b.color}`, { map: t.wood, color: b.color, roughness: 0.86 });
  const roof = mat(`sr-${b.roof ?? 0x3a6a48}`, { map: t.dirt, color: b.roof ?? 0x3a6a48, roughness: 0.8 });
  const awning = mat("awning", { color: 0xc45c4a, roughness: 0.7 });
  const wood = mat("wood", { map: t.wood, color: 0x5a4634, roughness: 0.9 });
  const glow = mat(night ? "store-n" : "store-d", {
    color: 0xf0d8a8,
    emissive: 0xf0d8a8,
    emissiveIntensity: night ? 0.9 : 0.2,
  });

  box(g, b.w, b.h, b.d, wall, 0, y0 + b.h / 2, 0);
  box(g, b.w + 0.8, 0.14, b.d / 2 + 0.6, roof, 0, y0 + b.h + 0.45, 0.1, -0.35, 0, 0);
  box(g, b.w + 0.4, 0.08, 1.6, awning, 0, y0 + 2.4, -b.d / 2 - 0.7, 0.25, 0, 0);
  box(g, b.w - 0.8, 1.1, 0.08, glow, 0, y0 + 1.35, -b.d / 2 - 0.05);
  box(g, b.w - 0.6, 0.12, 0.7, wood, 0, y0 + 0.85, -b.d / 2 - 0.4);
}

function buildWorkshop(g: THREE.Group, b: Building, y0: number, _night: boolean) {
  const t = maps();
  const wall = mat(`ww-${b.color}`, { map: t.concrete, color: b.color, roughness: 0.88 });
  const roof = mat(`wr-${b.roof ?? 0x5a4c38}`, { map: t.metal, color: b.roof ?? 0x5a4c38, roughness: 0.82, metalness: 0.18 });
  const metal = mat("iron", { map: t.metal, color: 0x2a2e2c, roughness: 0.5, metalness: 0.4 });
  box(g, b.w, b.h, b.d, wall, 0, y0 + b.h / 2, 0);
  box(g, b.w + 0.8, 0.16, b.d + 0.6, roof, 0, y0 + b.h + 0.2, 0, 0.08, 0, 0);
  box(g, 1.8, 2.2, 0.1, metal, 0, y0 + 1.2, -b.d / 2 - 0.04);
  box(g, 0.5, 0.5, 0.06, mat("win", { color: 0x8aa0b8, roughness: 0.3, metalness: 0.3 }), b.w * 0.28, y0 + 2.4, -b.d / 2 - 0.05);
}

function buildGreenhouse(g: THREE.Group, b: Building, y0: number, night: boolean) {
  const t = maps();
  const frame = mat("gframe", { map: t.metal, color: 0x3a4a40, roughness: 0.55, metalness: 0.25 });
  const glass = mat(night ? "gglass-n" : "gglass-d", {
    color: 0x8aa99a,
    transparent: true,
    opacity: 0.45,
    roughness: 0.2,
    metalness: 0.15,
    emissive: 0x6fad7a,
    emissiveIntensity: night ? 0.35 : 0.08,
    depthWrite: false,
  });
  box(g, b.w, 0.3, b.d, frame, 0, y0 + 0.15, 0);
  box(g, b.w - 0.2, b.h - 0.4, b.d - 0.2, glass, 0, y0 + b.h / 2, 0, 0, 0, 0, false);
  box(g, b.w + 0.4, 0.12, b.d / 2 + 0.4, frame, 0, y0 + b.h + 0.35, -b.d / 4, 0.4, 0, 0);
  box(g, b.w + 0.4, 0.12, b.d / 2 + 0.4, frame, 0, y0 + b.h + 0.35, b.d / 4, -0.4, 0, 0);
  box(g, 1.4, 2.2, 0.1, frame, 0, y0 + 1.2, -b.d / 2 - 0.04);
}

function buildMill(g: THREE.Group, b: Building, y0: number, night: boolean) {
  const t = maps();
  const wall = mat(`mw-${b.color}`, { map: t.wood, color: b.color, roughness: 0.86 });
  const roof = mat(`mr-${b.roof ?? 0x5a4c38}`, { map: t.metal, color: b.roof ?? 0x5a4c38, roughness: 0.8, metalness: 0.2 });
  const glow = mat(night ? "mill-n" : "mill-d", {
    color: 0xc4a15a,
    emissive: 0xc4a15a,
    emissiveIntensity: night ? 0.7 : 0.15,
  });
  box(g, b.w, b.h, b.d, wall, 0, y0 + b.h / 2, 0);
  box(g, b.w + 0.6, 0.16, b.d + 0.6, roof, 0, y0 + b.h + 0.15, 0);
  box(g, 1.1, 1.4, 0.08, glow, 0, y0 + 2.2, -b.d / 2 - 0.05);
  box(g, 0.9, 2.0, 0.12, mat("doorw", { map: t.wood, color: 0x3a2a1c, roughness: 0.9 }), -b.w * 0.22, y0 + 1.1, -b.d / 2 - 0.04);
}

export function buildJeepney(): THREE.Group {
  const g = new THREE.Group();
  const t = maps();
  const body = mat("jeep", { color: 0xc45c4a, roughness: 0.55, metalness: 0.15, roughnessMap: t.rough });
  const chrome = mat("chrome", { map: t.metal, color: 0xc5d0c4, roughness: 0.3, metalness: 0.7 });
  const tire = mat("tire", { color: 0x1a1e1c, roughness: 0.9 });
  const roof = mat("jroof", { color: 0xc4a15a, roughness: 0.6 });
  box(g, 5.6, 1.4, 2.1, body, 0, 1.05, 0);
  box(g, 2.2, 1.1, 2.0, body, -2.1, 1.55, 0);
  box(g, 5.8, 0.08, 2.3, roof, 0, 2.15, 0);
  box(g, 0.08, 0.7, 1.6, mat("jwin", { color: 0x8aa0b8, roughness: 0.25, transparent: true, opacity: 0.55, depthWrite: false }), -3.15, 1.6, 0);
  for (const [x, z] of [
    [-1.8, 1.15],
    [1.6, 1.15],
    [-1.8, -1.15],
    [1.6, -1.15],
  ] as [number, number][]) {
    const w = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.38, 0.28, 10), tire);
    w.rotation.z = Math.PI / 2;
    w.position.set(x, 0.38, z);
    g.add(w);
  }
  box(g, 0.5, 0.16, 0.16, chrome, -3.0, 0.7, 0.7, 0, 0, 0, false);
  box(g, 0.5, 0.16, 0.16, chrome, -3.0, 0.7, -0.7, 0, 0, 0, false);
  return g;
}

export function buildWell(): THREE.Group {
  const g = new THREE.Group();
  const t = maps();
  const stone = mat("stone", { map: t.stone, color: 0x5a5e56, roughness: 0.95 });
  const wood = mat("wood", { map: t.wood, color: 0x5a4634, roughness: 0.9 });
  const roof = mat("hr-0x8a4030", { map: t.dirt, color: 0x8a4030, roughness: 0.78 });
  const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.05, 0.9, 12), stone);
  ring.position.y = 0.45;
  g.add(ring);
  box(g, 0.12, 1.6, 0.12, wood, -0.7, 1.3, 0);
  box(g, 0.12, 1.6, 0.12, wood, 0.7, 1.3, 0);
  box(g, 2.0, 0.08, 1.1, roof, 0, 2.15, 0, 0.25, 0, 0);
  return g;
}

export function buildBoat(): THREE.Group {
  const g = new THREE.Group();
  const t = maps();
  const wood = mat("boat", { map: t.wood, color: 0x5a4634, roughness: 0.85 });
  box(g, 3.4, 0.28, 1.05, wood, 0, 0.2, 0);
  box(g, 2.6, 0.22, 0.16, wood, 0, 0.4, 0.42);
  box(g, 2.6, 0.22, 0.16, wood, 0, 0.4, -0.42);
  box(g, 0.12, 1.4, 0.12, wood, 0.4, 0.9, 0);
  return g;
}

export function buildClothesline(): THREE.Group {
  const g = new THREE.Group();
  const t = maps();
  const wood = mat("wood", { map: t.wood, color: 0x5a4634, roughness: 0.9 });
  const cloths = [0xe8e0d0, 0x4a6a48, 0xc45c4a, 0x8aa0b8];
  box(g, 0.1, 2.0, 0.1, wood, -2.2, 1.0, 0);
  box(g, 0.1, 2.0, 0.1, wood, 2.2, 1.0, 0);
  box(g, 4.4, 0.03, 0.03, wood, 0, 1.85, 0, 0, 0, 0, false);
  cloths.forEach((c, i) => {
    const cloth = box(
      g,
      0.55,
      0.7,
      0.04,
      applyWind(mat(`cloth-${c}`, { color: c, roughness: 0.9, side: THREE.DoubleSide }), 1.4, true),
      -1.5 + i * 1.05,
      1.5,
      0,
      0.08,
      0,
      0,
      false,
    );
    cloth.userData.cloth = true;
  });
  return g;
}

export function buildTableSet(): THREE.Group {
  const g = new THREE.Group();
  const t = maps();
  const wood = mat("wood", { map: t.wood, color: 0x5a4634, roughness: 0.9 });
  box(g, 1.4, 0.08, 0.8, wood, 0, 0.72, 0);
  box(g, 0.08, 0.72, 0.08, wood, -0.55, 0.36, -0.28);
  box(g, 0.08, 0.72, 0.08, wood, 0.55, 0.36, -0.28);
  box(g, 0.08, 0.72, 0.08, wood, -0.55, 0.36, 0.28);
  box(g, 0.08, 0.72, 0.08, wood, 0.55, 0.36, 0.28);
  box(g, 0.4, 0.08, 0.4, wood, 1.1, 0.45, 0.15);
  box(g, 0.4, 0.08, 0.4, wood, -1.1, 0.45, -0.1);
  return g;
}

export function resetStructureMaterials() {
  matCache.clear();
}
