import * as THREE from "three";

const SKIN = 0xc49a72;
const SKIN_SHADOW = 0xa07a58;
const SHIRT = 0xe8e4d8;
const SHORTS = 0x3a4a40;
const HAIR = 0x1a1614;
const FLASH_BODY = 0x2a322e;
const FLASH_LENS = 0xf0d8a8;

function mat(color: number, extra: THREE.MeshStandardMaterialParameters = {}) {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.72, metalness: 0.04, ...extra });
}

function add(
  g: THREE.Group,
  geo: THREE.BufferGeometry,
  material: THREE.Material,
  x: number,
  y: number,
  z: number,
  rx = 0,
  ry = 0,
  rz = 0,
) {
  const m = new THREE.Mesh(geo, material);
  m.position.set(x, y, z);
  m.rotation.set(rx, ry, rz);
  m.castShadow = true;
  g.add(m);
  return m;
}

export function buildFlashlightHand(): THREE.Group {
  const g = new THREE.Group();
  const skin = mat(SKIN);
  const skinD = mat(SKIN_SHADOW);
  const sleeve = mat(SHIRT);
  const metal = mat(FLASH_BODY, { metalness: 0.48, roughness: 0.38 });
  const lens = mat(FLASH_LENS, { emissive: FLASH_LENS, emissiveIntensity: 0.15, roughness: 0.25 });

  const arm = add(g, new THREE.CylinderGeometry(0.028, 0.034, 0.22, 8), sleeve, 0.0, -0.02, 0.12, 1.05, 0, 0.18);
  arm.castShadow = false;
  add(g, new THREE.BoxGeometry(0.055, 0.03, 0.08), skin, 0.0, -0.01, -0.02, 0.2, 0, 0.1);
  add(g, new THREE.BoxGeometry(0.018, 0.022, 0.05), skinD, -0.032, 0.012, -0.01, 0.4, 0.4, 0.8);
  add(g, new THREE.BoxGeometry(0.014, 0.016, 0.048), skin, 0.018, 0.018, -0.05, 0.55, 0, 0);
  add(g, new THREE.BoxGeometry(0.013, 0.015, 0.046), skin, 0.004, 0.02, -0.055, 0.6, 0, 0);
  add(g, new THREE.BoxGeometry(0.012, 0.014, 0.04), skin, -0.01, 0.018, -0.05, 0.55, 0, 0);

  const torch = new THREE.Group();
  torch.position.set(0.0, 0.0, -0.08);
  torch.rotation.set(0.12, 0, 0);
  const body = add(torch, new THREE.CylinderGeometry(0.022, 0.026, 0.16, 10), metal, 0, 0, 0, Math.PI / 2);
  body.castShadow = false;
  const bezel = add(torch, new THREE.CylinderGeometry(0.03, 0.028, 0.03, 10), metal, 0, 0, -0.09, Math.PI / 2);
  bezel.castShadow = false;
  const glass = add(torch, new THREE.CylinderGeometry(0.024, 0.024, 0.012, 10), lens, 0, 0, -0.108, Math.PI / 2);
  glass.castShadow = false;
  g.add(torch);

  g.userData.lens = glass;
  g.userData.torch = torch;
  g.position.set(0.24, -0.26, -0.44);
  g.rotation.set(0.18, 0.22, 0.28);
  return g;
}

export function buildPlayerBody(): THREE.Group {
  const g = new THREE.Group();
  g.name = "player-body";
  const skin = mat(SKIN);
  const shirt = mat(SHIRT);
  const shorts = mat(SHORTS);
  const hair = mat(HAIR);
  const shoes = mat(0x2a322c);

  add(g, new THREE.CylinderGeometry(0.09, 0.1, 0.42, 8), shorts, 0, 0.72, 0);
  add(g, new THREE.CylinderGeometry(0.12, 0.14, 0.48, 8), shirt, 0, 1.12, 0);
  add(g, new THREE.SphereGeometry(0.13, 10, 8), skin, 0, 1.48, 0);
  add(g, new THREE.SphereGeometry(0.135, 10, 8), hair, 0, 1.54, -0.01);
  add(g, new THREE.CylinderGeometry(0.045, 0.05, 0.46, 6), skin, -0.18, 1.05, 0, 0, 0, 0.12);
  add(g, new THREE.CylinderGeometry(0.045, 0.05, 0.46, 6), skin, 0.18, 1.05, 0, 0, 0, -0.12);
  add(g, new THREE.CylinderGeometry(0.048, 0.055, 0.52, 6), skin, -0.07, 0.38, 0);
  add(g, new THREE.CylinderGeometry(0.048, 0.055, 0.52, 6), skin, 0.07, 0.38, 0);
  add(g, new THREE.BoxGeometry(0.09, 0.05, 0.16), shoes, -0.07, 0.1, 0.02);
  add(g, new THREE.BoxGeometry(0.09, 0.05, 0.16), shoes, 0.07, 0.1, 0.02);

  const torch = new THREE.Group();
  const metal = mat(FLASH_BODY, { metalness: 0.48, roughness: 0.38 });
  const lens = mat(FLASH_LENS, { emissive: FLASH_LENS, emissiveIntensity: 0.2 });
  add(torch, new THREE.CylinderGeometry(0.025, 0.03, 0.18, 8), metal, 0, 0, 0, Math.PI / 2);
  const glass = add(torch, new THREE.CylinderGeometry(0.028, 0.028, 0.02, 8), lens, 0, 0, -0.1, Math.PI / 2);
  torch.position.set(0.28, 1.02, -0.16);
  torch.rotation.set(-0.15, 0, 0.15);
  g.add(torch);
  g.userData.lens = glass;
  g.userData.torch = torch;
  g.visible = false;
  return g;
}

export function makeFlashlight(): { light: THREE.SpotLight; fill: THREE.PointLight } {
  const light = new THREE.SpotLight(0xffe4c4, 0, 22, 0.46, 0.72, 1.45);
  light.castShadow = false;
  const fill = new THREE.PointLight(0xffe8d0, 0, 3.8, 2);
  fill.castShadow = false;
  return { light, fill };
}
